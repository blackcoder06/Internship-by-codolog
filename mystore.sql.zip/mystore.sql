-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jul 09, 2024 at 04:03 PM
-- Server version: 8.0.37
-- PHP Version: 8.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mystore`
--

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

DROP TABLE IF EXISTS `brands`;
CREATE TABLE IF NOT EXISTS `brands` (
  `brand_id` int NOT NULL AUTO_INCREMENT,
  `brand_title` varchar(100) NOT NULL,
  PRIMARY KEY (`brand_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`brand_id`, `brand_title`) VALUES
(1, 'zomato'),
(2, 'swiggy'),
(3, 'MCDonals'),
(4, 'HP'),
(5, 'Amazon'),
(6, 'Flipkart');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `category_id` int NOT NULL AUTO_INCREMENT,
  `category_title` varchar(100) NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `category_title`) VALUES
(1, 'fruits'),
(2, 'jucies'),
(3, 'vegetable'),
(4, 'underwear'),
(5, 'books'),
(6, 'jhula'),
(7, 'mobile'),
(8, 'shoes'),
(9, 'keyboard');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `product_id` int NOT NULL AUTO_INCREMENT,
  `product_title` varchar(100) NOT NULL,
  `product_description` varchar(255) NOT NULL,
  `product_keywords` varchar(255) NOT NULL,
  `categoroy_id` int NOT NULL,
  `brand_id` int NOT NULL,
  `product_image1` varchar(255) NOT NULL,
  `product_image2` varchar(255) NOT NULL,
  `product_image3` varchar(255) NOT NULL,
  `product_price` varchar(100) NOT NULL,
  `date` timestamp NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_title`, `product_description`, `product_keywords`, `categoroy_id`, `brand_id`, `product_image1`, `product_image2`, `product_image3`, `product_price`, `date`, `status`) VALUES
(1, 'watches', 'branded watches best watches', 'watches ,branded watches.amazon', 4, 5, 'img7.jpg', 'img7.jpg', 'img7.jpg', '1500', '2024-07-01 18:50:54', 'true'),
(2, 'flute', 'musical flute', 'Amazon , flute , music.Amazon', 4, 5, 'img4.jpg', 'img4.jpg', 'img4.jpg', '850', '2024-07-01 18:52:06', 'true'),
(3, 'jhula', 'jhula hula hula', 'jhula.flipkart', 6, 6, 'img6.jpg', 'img6.jpg', 'img6.jpg', '560', '2024-07-01 19:00:14', 'true'),
(4, 'phone', '12gb ram, 512gb internal storage,16.5 inches display', 'mobile,phone,amazon ', 7, 5, 'phone.webp', 'phone1.webp', 'phone.webp', '15000', '2024-07-04 11:08:05', 'true'),
(5, 'shoes', 'branded shoes , black shoes , best in market', 'shoes , amazon , black', 8, 5, 'shoes.webp', 'shoes1.webp', 'shoes.webp', '2000', '2024-07-04 11:12:12', 'true'),
(6, 'keyboard', 'laptop keyboard , wireless , branded ', 'keyboard , flipkart', 9, 6, 'keyboard.webp', 'keyboard1.webp', 'keyboard1.webp', '650', '2024-07-04 11:13:11', 'true'),
(8, 'veggis', 'any veg', 'tomato , blinkit', 3, 3, 'tomato2.jpg', 'tomato1.webp', 'tomato.webp', '20kg', '2024-07-09 15:54:41', 'true');

-- --------------------------------------------------------

--
-- Table structure for table `user_table`
--

DROP TABLE IF EXISTS `user_table`;
CREATE TABLE IF NOT EXISTS `user_table` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `user_email` varchar(100) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `user_image` varchar(255) NOT NULL,
  `user_address` varchar(255) NOT NULL,
  `user_mobile` varchar(20) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user_table`
--

INSERT INTO `user_table` (`user_id`, `username`, `user_email`, `user_password`, `user_image`, `user_address`, `user_mobile`) VALUES
(1, 'dev', 'dev@gamil.com', '$2y$10$fSAnuWpM/HDYcdp/8kFLDe/nm2.RrJ1iRnthIku0muh0BfYqGXjkC', 'img3.jpg', ' mumbai', '3571598'),
(2, 'ash', 'ash@gmail.com', '$2y$10$2bCzwwMK5kHjPpZw9p/qXeVhaQNUzrJzowyHaYN2yoMhbUUKdkHO6', 'img3.jpg', ' pune', '7539512'),
(3, 'avi', 'avi@gmail.com', '$2y$10$Hfri5ErgXLGZkijDaoZGFeBSELIPETFAylRZ7DAQOhA4xUgpNNVAi', 'img3.jpg', ' pune', '398563741');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
